

<?php $__env->startSection('content'); ?>


<div class="py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="shadow bg-white p-3">

                <h4 class="mb-4">My Orders </h4>

    <div class="table-responsive">
        <table class="table table-bordered-table-striped">

        <thead>
            <th>Order ID </th>
            <th>image </th>
            <th>Order Name</th>
            <th>Tracking No </th>
            <th>Order Description</th>
            <th>Order Date </th>

        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td> <?php echo e($item->id); ?> </td>
                <td> 
                <img width="40px" height="50" src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"/>    
                </td>  
                <td> <?php echo e($item->name); ?> </td>
                <td> <?php echo e($item->tracking_no); ?> </td>  
                <td> <?php echo e($item->description); ?> </td>  
                <td> <?php echo e($item->created_at); ?> </td>
                  
               

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="5"> No Order Available</td>
            </tr>
        <?php endif; ?>

        </tbody>

        
        </table>
        <div>
        <?php echo e($orders->links()); ?>

</div>
<a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary">Go Back</a>


</div>
</div>
</div>
</div>
</div>
</div>
</div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Swazei_Project\resources\views/order/index.blade.php ENDPATH**/ ?>