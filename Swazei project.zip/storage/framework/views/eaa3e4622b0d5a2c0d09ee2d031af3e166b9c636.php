

<?php $__env->startSection('content'); ?>


<div class="container">
    <h1 class="text-center">Cart Page</h1>
    <div class="row">
    <table class="table table-hover">
    <thead>
        <tr>
            <th width="50%">Product</th>
            <th width="10%">Price</th>
            <th width="8%">Quantity</th>
            <th width="22%">Sub Total</th>
            <th width="10%">Product</th>
        </tr>
    </thead>
        <tbody>

        <?php $total = 0; ?>
        <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $subTotal = $value['price'] * $value['quantity'];
                $total += $subTotal;  

            ?>


           <tr>
            <td>
                <img src="<?php echo e($value['image']); ?>" 
                alt="<?php echo e($value['name']); ?>" 
                class="img-fluid" 
                width="150">
                <span> <?php echo e($value['name']); ?></span>
            </td>
            <td>₹<?php echo e($value['price']); ?></td>
            <td><?php echo e($value['quantity']); ?></td>
            <td>₹<?php echo e($subTotal); ?></td>
            <td>
                <a href="<?php echo e(route('remove',[$id])); ?>" class="btn btn-danger">Remove</a>
            </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        </tbody>

        <tfoot>
        <tr>
            <td>
            <a href="<?php echo e(route('products')); ?>" class="btn btn-warning">Continue Shopping</a></td>
            <td colspan="2"></td>
            <td><strong>Total ₹. <?php echo e($total); ?></strong</td>

            <form action="<?php echo e(route ('placeOrder')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <td>
                <button type="submit" class="btn btn-success">Place Order </button>
            </td>

            </form>
         


        </tr>
        

        </tfoot>
    
</table>

<a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary">Go Back</a>


</div>
</div>



    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Swazei_Project\resources\views/cart.blade.php ENDPATH**/ ?>