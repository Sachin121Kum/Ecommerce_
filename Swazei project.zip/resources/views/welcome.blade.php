@extends('auth.layouts')

@section('content')




<div>

    <h1>Product Page</h1>




</div>

@endsection